package com.tallerpro.ui.screens
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tallerpro.ui.HomeState
@Composable
fun HomeScreen(state: HomeState, onNuevaOT: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Taller Pro") }) },
        floatingActionButton = { FloatingActionButton(onClick = onNuevaOT) { Icon(Icons.Default.Add, contentDescription = "Nueva OT") } }
    ) { p ->
        Column(Modifier.padding(p).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Panel", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                KPI("OT abiertas", state.abiertas); KPI("Para hoy", state.hoy); KPI("Retrasadas", state.retrasadas)
            }
            Card(Modifier.fillMaxWidth().clickable { onNuevaOT() }) {
                Column(Modifier.padding(16.dp)) {
                    Text("Crear nueva Orden de Trabajo", style = MaterialTheme.typography.titleMedium)
                    Text("Diagnóstico, servicios, piezas y total.")
                }
            }
        }
    }
}
@Composable private fun KPI(titulo: String, valor: Int) {
    Card(Modifier.weight(1f)) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(titulo); Text("$valor", style = MaterialTheme.typography.headlineMedium)
        }
    }
}
