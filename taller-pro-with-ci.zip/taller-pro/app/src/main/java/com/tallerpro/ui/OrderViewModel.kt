package com.tallerpro.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.SavedStateHandle
import com.tallerpro.data.*
import com.tallerpro.data.repo.TallerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ServicioInput(var desc: String = "", var horas: String = "", var precioHora: String = "")
data class PiezaInput(var codigo: String = "", var desc: String = "", var cant: String = "1", var precio: String = "")

data class OrdenUiState(
    val ordenId: Long = 0L,
    val clienteNombre: String = "",
    val vehiculoLabel: String = "",
    val matricula: String = "",
    val servicios: List<Servicio> = emptyList(),
    val piezas: List<Pieza> = emptyList(),
    val total: Double = 0.0
)

@HiltViewModel
class OrderViewModel @Inject constructor(
    private val clienteDao: ClienteDao,
    private val vehiculoDao: VehiculoDao,
    private val ordenDao: OrdenDao,
    private val servicioDao: ServicioDao,
    private val piezaDao: PiezaDao,
    private val repo: TallerRepository,
    private val stateHandle: SavedStateHandle
): ViewModel() {

    private val _state = MutableStateFlow(OrdenUiState())
    val state: StateFlow<OrdenUiState> = _state.asStateFlow()

    val servicioInput = MutableStateFlow(ServicioInput())
    val piezaInput = MutableStateFlow(PiezaInput())

    init {
        viewModelScope.launch {
            val argId: Long? = stateHandle.get<Long>("ordenId")
            if (argId != null && argId > 0) {
                load(argId)
            } else {
                // create demo cliente/vehiculo and a new order
                val cId = clienteDao.insert(Cliente(nombre = "Cliente demo")).first()
                val vId = vehiculoDao.insert(Vehiculo(clienteId = cId, marca = "Genérico", modelo = "Modelo", matricula = "XXX-000")).first()
                val oId = ordenDao.insert(OrdenTrabajo(vehiculoId = vId)).first()
                load(oId)
                stateHandle["ordenId"] = oId
            }
        }
    }

    private suspend fun load(ordenId: Long) {
        val orden = ordenDao.getById(ordenId) ?: return
        val vehiculo = vehiculoDao.getById(orden.vehiculoId)
        val cliente = vehiculo?.let { clienteDao.getById(it.clienteId) }
        val servicios = servicioDao.porOrden(ordenId)
        val piezas = piezaDao.porOrden(ordenId)
        val total = repo.totalOrden(ordenId)
        _state.value = OrdenUiState(
            ordenId = ordenId,
            clienteNombre = cliente?.nombre ?: "",
            vehiculoLabel = vehiculo?.let { "${it.marca} ${it.modelo}" } ?: "",
            matricula = vehiculo?.matricula ?: "",
            servicios = servicios,
            piezas = piezas,
            total = total
        )
    }

    fun agregarServicio() = viewModelScope.launch {
        val s = servicioInput.value
        val horas = s.horas.toDoubleOrNull() ?: 0.0
        val precio = s.precioHora.toDoubleOrNull() ?: 0.0
        if (s.desc.isNotBlank() && horas > 0) {
            servicioDao.insert(Servicio(ordenId = _state.value.ordenId, descripcion = s.desc, horas = horas, precioHora = precio))
            servicioInput.value = ServicioInput()
            load(_state.value.ordenId)
        }
    }

    fun agregarPieza(codigo: String? = null) = viewModelScope.launch {
        val p = piezaInput.value
        val cant = p.cant.toIntOrNull() ?: 1
        val precio = p.precio.toDoubleOrNull() ?: 0.0
        val code = codigo ?: p.codigo
        if (code.isNotBlank()) {
            piezaDao.insert(Pieza(ordenId = _state.value.ordenId, codigo = code, descripcion = if (p.desc.isBlank()) code else p.desc, cantidad = cant, precioUnit = precio))
            piezaInput.value = PiezaInput()
            load(_state.value.ordenId)
        }
    }
}
