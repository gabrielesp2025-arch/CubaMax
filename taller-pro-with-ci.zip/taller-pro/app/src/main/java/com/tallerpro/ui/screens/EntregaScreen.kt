package com.tallerpro.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import com.tallerpro.ui.OrderViewModel
import com.tallerpro.ui.SignaturePad
import com.tallerpro.util.PdfUtils

@Composable
fun EntregaScreen(onBack: () -> Unit) {
    val vm: OrderViewModel = hiltViewModel()
    val state by vm.state.collectAsState()
    var lastBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val ctx = LocalContext.current

    Column(Modifier.padding(16.dp)) {
        Text("Firma del cliente para OT #${state.ordenId}")
        Spacer(Modifier.height(8.dp))
        SignaturePad(modifier = Modifier.fillMaxWidth().height(200.dp), onExport = { bmp -> lastBitmap = bmp })
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val bmp = lastBitmap ?: return@Button
            val uri = PdfUtils.crearPdfEntrega(
                context = ctx,
                resumen = PdfUtils.OrderSummary(
                    numero = state.ordenId.toString(),
                    cliente = state.clienteNombre,
                    vehiculo = state.vehiculoLabel,
                    matricula = state.matricula,
                    total = "€ %.2f".format(state.total),
                    notas = null
                ),
                firma = bmp
            )
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(share, "Compartir PDF de entrega"))
        }) { Text("Generar y compartir PDF") }
    }
}
