package com.tallerpro.di
import android.content.Context
import androidx.room.Room
import com.tallerpro.data.*
import com.tallerpro.data.repo.TallerRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton fun provideDb(@ApplicationContext ctx: Context): AppDatabase = Room.databaseBuilder(ctx, AppDatabase::class.java, "taller.db").build()
    @Provides fun provideClienteDao(db: AppDatabase) = db.clienteDao()
    @Provides fun provideVehiculoDao(db: AppDatabase) = db.vehiculoDao()
    @Provides fun provideOrdenDao(db: AppDatabase) = db.ordenDao()
    @Provides fun provideServicioDao(db: AppDatabase) = db.servicioDao()
    @Provides fun providePiezaDao(db: AppDatabase) = db.piezaDao()
    @Provides @Singleton fun provideRepo(ordenDao: OrdenDao, servicioDao: ServicioDao, piezaDao: PiezaDao) = TallerRepository(ordenDao, servicioDao, piezaDao)
}
