package com.tallerpro.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.SavedStateHandle
import com.tallerpro.data.Pieza
import com.tallerpro.data.PiezaDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScanViewModel @Inject constructor(
    private val piezaDao: PiezaDao,
    private val state: SavedStateHandle
): ViewModel() {
    val ordenId: Long = state.get<Long>("ordenId") ?: 0L
    fun onDetected(code: String) = viewModelScope.launch {
        if (ordenId > 0) {
            piezaDao.insert(Pieza(ordenId = ordenId, codigo = code, descripcion = code, cantidad = 1, precioUnit = 0.0))
        }
    }
}
