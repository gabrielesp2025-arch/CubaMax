package com.tallerpro.data.repo
import com.tallerpro.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
data class KPIs(val abiertas: Int, val hoy: Int, val retrasadas: Int)
class TallerRepository @Inject constructor(private val ordenDao: OrdenDao, private val servicioDao: ServicioDao, private val piezaDao: PiezaDao) {
    suspend fun kpis(): KPIs = withContext(Dispatchers.IO) { KPIs(abiertas = ordenDao.abiertas().size, hoy = 0, retrasadas = 0) }
    suspend fun totalOrden(ordenId: Long): Double = withContext(Dispatchers.IO) {
        val servicios = servicioDao.porOrden(ordenId); val piezas = piezaDao.porOrden(ordenId)
        servicios.sumOf { it.horas * it.precioHora } + piezas.sumOf { it.cantidad * it.precioUnit }
    }
}
