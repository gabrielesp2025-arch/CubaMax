package com.tallerpro.ui.screens

import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import androidx.hilt.navigation.compose.hiltViewModel
import com.tallerpro.ui.ScanViewModel

@Composable
fun ScanForOrderScreen(onBack: () -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val vm: ScanViewModel = hiltViewModel()
    var done by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Escanear para OT #${vm.ordenId}")
        Spacer(Modifier.height(8.dp))
        AndroidView(factory = { context ->
            val previewView = PreviewView(context)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val selector = CameraSelector.DEFAULT_BACK_CAMERA
                val analysis = ImageAnalysis.Builder().setTargetResolution(Size(1280, 720)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                val scanner = BarcodeScanning.getClient()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(context)) { imgProxy ->
                    val mediaImage = imgProxy.image
                    if (mediaImage != null && !done) {
                        val image = InputImage.fromMediaImage(mediaImage, imgProxy.imageInfo.rotationDegrees)
                        scanner.process(image).addOnSuccessListener { barcodes ->
                            val raw = barcodes.firstOrNull()?.rawValue
                            if (raw != null) {
                                vm.onDetected(raw)
                                done = true
                                onBack()
                            }
                        }.addOnCompleteListener { imgProxy.close() }
                    } else imgProxy.close()
                }
                try { cameraProvider.unbindAll(); cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, analysis) } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(context))
            previewView
        }, modifier = Modifier.weight(1f))
        Spacer(Modifier.height(12.dp))
        Button(onClick = onBack) { Text("Volver") }
    }
}
