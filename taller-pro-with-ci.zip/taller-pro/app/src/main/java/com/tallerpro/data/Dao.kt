package com.tallerpro.data
import androidx.room.*
@Dao interface ClienteDao { @Query("SELECT * FROM Cliente WHERE id = :id") suspend fun getById(id: Long): Cliente?; @Query("SELECT * FROM Cliente WHERE nombre LIKE '%' || :q || '%' ORDER BY nombre") suspend fun buscar(q: String): List<Cliente>; @Insert suspend fun insert(vararg c: Cliente): List<Long> }
@Dao interface VehiculoDao { @Query("SELECT * FROM Vehiculo WHERE id = :id") suspend fun getById(id: Long): Vehiculo?; @Query("SELECT * FROM Vehiculo WHERE matricula LIKE '%'||:q||'%' OR vin LIKE '%'||:q||'%' ORDER BY matricula") suspend fun buscar(q: String): List<Vehiculo>; @Insert suspend fun insert(vararg v: Vehiculo): List<Long> }
@Dao interface OrdenDao { @Query("SELECT * FROM OrdenTrabajo WHERE id = :id") suspend fun getById(id: Long): OrdenTrabajo?; @Query("SELECT * FROM OrdenTrabajo WHERE estado != 'ENTREGADO'") suspend fun abiertas(): List<OrdenTrabajo>; @Insert suspend fun insert(vararg o: OrdenTrabajo): List<Long> }
@Dao interface ServicioDao { @Query("SELECT * FROM Servicio WHERE ordenId = :ordenId") suspend fun porOrden(ordenId: Long): List<Servicio>; @Insert suspend fun insert(vararg s: Servicio): List<Long> }
@Dao interface PiezaDao { @Query("SELECT * FROM Pieza WHERE ordenId = :ordenId") suspend fun porOrden(ordenId: Long): List<Pieza>; @Insert suspend fun insert(vararg p: Pieza): List<Long> }
