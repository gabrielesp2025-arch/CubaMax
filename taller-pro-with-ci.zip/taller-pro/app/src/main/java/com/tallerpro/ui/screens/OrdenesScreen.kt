package com.tallerpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tallerpro.ui.OrderViewModel
import com.tallerpro.ui.ServicioInput
import com.tallerpro.ui.PiezaInput

@Composable
fun OrdenesScreen(vm: OrderViewModel, onBack: () -> Unit, onGoEntrega: (Long) -> Unit, onGoScan: (Long) -> Unit) {
    val state by vm.state.collectAsState()
    val sIn by vm.servicioInput.collectAsState()
    val pIn by vm.piezaInput.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("OT #${state.ordenId}") }) }) { p ->
        Column(Modifier.padding(p).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Cliente: ${state.clienteNombre}")
            Text("Vehículo: ${state.vehiculoLabel}  ·  Matrícula: ${state.matricula}")
            Divider()

            Text("Servicios", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(sIn.desc, { vm.servicioInput.value = sIn.copy(desc = it) }, label = { Text("Descripción") }, modifier = Modifier.weight(1f))
                OutlinedTextField(sIn.horas, { vm.servicioInput.value = sIn.copy(horas = it) }, label = { Text("Horas") }, modifier = Modifier.width(100.dp))
                OutlinedTextField(sIn.precioHora, { vm.servicioInput.value = sIn.copy(precioHora = it) }, label = { Text("€/h") }, modifier = Modifier.width(100.dp))
                Button(onClick = { vm.agregarServicio() }) { Text("Añadir") }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.heightIn(max = 180.dp)) {
                items(state.servicios) { s -> Text("• ${s.descripcion}: ${s.horas}h x €${s.precioHora}") }
            }

            Divider()
            Text("Piezas", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(pIn.codigo, { vm.piezaInput.value = pIn.copy(codigo = it) }, label = { Text("Código") }, modifier = Modifier.weight(1f))
                OutlinedTextField(pIn.desc, { vm.piezaInput.value = pIn.copy(desc = it) }, label = { Text("Descripción") }, modifier = Modifier.weight(1f))
                OutlinedTextField(pIn.cant, { vm.piezaInput.value = pIn.copy(cant = it) }, label = { Text("Cant.") }, modifier = Modifier.width(80.dp))
                OutlinedTextField(pIn.precio, { vm.piezaInput.value = pIn.copy(precio = it) }, label = { Text("€/u") }, modifier = Modifier.width(100.dp))
                Button(onClick = { vm.agregarPieza() }) { Text("Añadir") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onGoScan(state.ordenId) }) { Text("Escanear pieza") }
                Button(onClick = { onGoEntrega(state.ordenId) }) { Text("Entrega (PDF + firma)") }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f, fill = true)) {
                items(state.piezas) { p -> Text("• ${p.codigo} ${p.descripcion}: ${p.cantidad} x €${p.precioUnit}") }
            }

            Divider()
            Text("Total: €${"%.2f".format(state.total)}", style = MaterialTheme.typography.titleLarge)
        }
    }
}
