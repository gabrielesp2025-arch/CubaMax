package com.tallerpro.ui
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tallerpro.ui.screens.*


sealed class Routes(val route: String){
    data object Home: Routes("home")
    data object Ordenes: Routes("ordenes") // creates a new order when no id is passed
    data object Entrega: Routes("entrega/{ordenId}")
    data object Scan: Routes("scan/{ordenId}")
}


@Composable
fun TallerProNavHost(navController: NavHostController = rememberNavController()) {
    
NavHost(navController = navController, startDestination = Routes.Home.route) {
    composable(Routes.Home.route) {
        val vm: HomeViewModel = hiltViewModel()
        HomeScreen(state = vm.state, onNuevaOT = { navController.navigate(Routes.Ordenes.route) })
    }
    composable(Routes.Ordenes.route) {
        val ovm: OrderViewModel = hiltViewModel()
        OrdenesScreen(
            vm = ovm,
            onBack = { navController.popBackStack() },
            onGoEntrega = { id -> navController.navigate("entrega/$id") },
            onGoScan = { id -> navController.navigate("scan/$id") }
        )
    }
    composable("entrega/{ordenId}") {
        EntregaScreen(onBack = { navController.popBackStack() })
    }
    composable("scan/{ordenId}") {
        ScanForOrderScreen(onBack = { navController.popBackStack() })
    }
}
