package com.tallerpro.data
import androidx.room.*
@Entity data class Cliente(@PrimaryKey(autoGenerate = true) val id: Long = 0, val nombre: String, val telefono: String? = null, val email: String? = null)
@Entity(foreignKeys=[ForeignKey(entity=Cliente::class,parentColumns=["id"],childColumns=["clienteId"],onDelete=ForeignKey.CASCADE)], indices=[Index("clienteId"), Index("matricula"), Index("vin")])
data class Vehiculo(@PrimaryKey(autoGenerate = true) val id: Long = 0, val clienteId: Long, val marca: String, val modelo: String, val anio: Int? = null, val vin: String? = null, val matricula: String)
@Entity(foreignKeys=[ForeignKey(entity=Vehiculo::class,parentColumns=["id"],childColumns=["vehiculoId"],onDelete=ForeignKey.CASCADE)], indices=[Index("vehiculoId")])
data class OrdenTrabajo(@PrimaryKey(autoGenerate = true) val id: Long = 0, val vehiculoId: Long, val fecha: Long = System.currentTimeMillis(), val estado: String = "PENDIENTE", val kilometraje: Int? = null, val notas: String? = null)
@Entity(foreignKeys=[ForeignKey(entity=OrdenTrabajo::class,parentColumns=["id"],childColumns=["ordenId"],onDelete=ForeignKey.CASCADE)], indices=[Index("ordenId")])
data class Servicio(@PrimaryKey(autoGenerate = true) val id: Long = 0, val ordenId: Long, val descripcion: String, val horas: Double, val precioHora: Double)
@Entity(foreignKeys=[ForeignKey(entity=OrdenTrabajo::class,parentColumns=["id"],childColumns=["ordenId"],onDelete=ForeignKey.CASCADE)], indices=[Index("ordenId"), Index("codigo")])
data class Pieza(@PrimaryKey(autoGenerate = true) val id: Long = 0, val ordenId: Long, val codigo: String, val descripcion: String, val cantidad: Int, val precioUnit: Double)
